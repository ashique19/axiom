<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Untitled Document</title>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="wrapper">
<div class="header">
<div class="logo">
<img src="images/logo.png" />
</div>
<div class="menu">
<p>1-888-412-9634</p>
<ul>
<li><a href="#">Enhance Score</a></li>
<li><a href="#">About</a></li>
<li><a href="#">FAQ’s</a></li>
<li><a href="#">Blog</a></li>
<li><a href="#">Contact</a></li>
<li><a href="#">Login</a></li>
</ul>
</div>
</div><!--header-->
<div class="content">
<div class="slider">
<div class="slide_content">
<h1>Fastest Score Possible...</h1>
<h2>Credit Score Boost!</h2>
<ul>
<li>
<img src="images/boost.png" />
<p>BOOST<span>My Credit <br />Scotre</span></p>
</li>
<li>
<img src="images/cash.png" />
<p>BOOST<span>My Credit <br />Scotre</span></p>
</li>
<li>
<img src="images/case.png" />
<p>BOOST<span>My Credit <br />Scotre</span></p>
</li>
</ul>
</div>
<img src="images/slide_img.png" />
</div>
<br style="clear:both" />
<div class="div_1">
<div class="inner_div">
<h2>the process</h2>
<ul>
<li><img src="images/card.png" /><p>Browse All Tradelines</p></li>
<li><img src="images/circle.png" /><p>Make Your Selection</p></li>
<li><img src="images/file.png" /><p>Submit Your Boost From</p></li>
<li><img src="images/phone.png" /><p>Receive Verification Call</p></li>
<li><img src="images/dollar.png" /><p>Make Payment</p></li>
<li><img src="images/lappy.png" /><p>Complete Online Profile</p></li>
<li><img src="images/shakehand.png" /><p>Wait For Your Boost</p></li>
</ul>
</div>
</div>
<div class="div_2">
<div class="inner_div">
<h2>how it works</h2>
<div class="white_text">
<p>Real Management Services adds your name as an Authorized User (AU) on one of our low balance credit cards that have perfect payment history. An AU is an individual that does not have access to the account, cannot make changes to it, nor have the responsibility to repay any amount that might be owed. The original intent of the AU designation was to give Primary Cardholders the ability to add their children, spouses, friends or employees to their accounts, effectively giving them access to the available credit line by use of an Authorized User credit card. Without that card the user isn’t even able to spend money on the credit account. An incidental benefit that occurs during this process is that the account history for that credit card appears on the AU’s (your) credit report; it looks like that credit card’s history has been there since the account was first opened. This "incidental benefit" gives you an immediate FICO® credit score boost.
<br /><br />
Although you do not receive the physical card or ability to use the credit line, you will receive the amazing benefit of having that particular credit card’s credit history appear on your credit report. This extreme increase in the limit to balance (utilization) ratio and overall average age of the revolving accounts on your credit report gives you the biggest possible FICO® score boost in less than 60 days; and it's guaranteed!</p>
<br /><br />
<a href="#">find out more</a>
</div>
</div>
</div>
<div class="div_3">
<div class="inner_div">
<p>Take advantage of this great benefit! </p>
<h2>1-888-412-9634</h2>
</div>
</div>
<div class="div_4">
<div class="inner_div">
<h2>how to make money</h2>
<p>Use your good credit to earn extra <span>cash!</span></p>
<div class="text_box">
<h3>Become a Cardholder</h3>
<p>We pay Cardholders just like you a fee for adding our clients as Authorized Users (AU) to their credit cards. The Authorizer User does not have access to spend money from your account - they don not know who you are - and they are paying ONLY for the benefit of seeing your credit card's payment history appear on their credit report.</p><br />
<a href="#">get started</a>
</div>
<div class="text_box">
<h3>Become a Cardholder</h3>
<p>We pay Cardholders just like you a fee for adding our clients as Authorized Users (AU) to their credit cards. The Authorizer User does not have access to spend money from your account - they don not know who you are - and they are paying ONLY for the benefit of seeing your credit card's payment history appear on their credit report.</p><br />
<a href="#">get started</a>
</div>
</div>
</div>
</div>
<div class="footer">
<div class="inner_div">
<img src="images/foot-logo.png" />
<div class="foot-right">
<h4>CONTACT US</h4>
<p>Real Management Services, Inc.<br />
244 Fifth Avenue Suite R273<br />
New York, NY 10001<br />
Phone: 1-888-412-9634<br />
<a href="#">support@realmanagementservices.net</a></p>
<p><u>Privacy Policy<br />
Legal Documents and Disclosures</u><br />
© 2016 Real Management Services</p>
</ul>
</div>
</div>
</div>
</div>
</body>
</html>
